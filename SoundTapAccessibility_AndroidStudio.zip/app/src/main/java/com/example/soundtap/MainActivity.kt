package com.example.soundtap

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var x1: EditText; private lateinit var y1: EditText
    private lateinit var x2: EditText; private lateinit var y2: EditText
    private lateinit var count: EditText; private lateinit var delay: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,30,30,30)}
        fun addLabel(s:String){root.addView(TextView(this).apply{text=s;textSize=16f})}
        fun addEdit(default:String):EditText{
            val e=EditText(this).apply{setText(default);inputType=2}
            root.addView(e); return e
        }
        root.addView(TextView(this).apply{text="Sound Tap Helper";textSize=24f})
        addLabel("Button 1 X"); x1=addEdit("500")
        addLabel("Button 1 Y"); y1=addEdit("1200")
        addLabel("Button 2 X"); x2=addEdit("800")
        addLabel("Button 2 Y"); y2=addEdit("1200")
        addLabel("Tap count"); count=addEdit("1")
        addLabel("Tap interval (ms)"); delay=addEdit("100")
        root.addView(Button(this).apply{text="Enable Accessibility Service";setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}})
        root.addView(Button(this).apply{text="Test Button 1";setOnClickListener{test(1)}})
        root.addView(Button(this).apply{text="Test Button 2";setOnClickListener{test(2)}})
        setContentView(root)
    }
    private fun test(which:Int){
        val s=TapAccessibilityService.instance ?: run {Toast.makeText(this,"Enable Accessibility first",Toast.LENGTH_LONG).show();return}
        val x=(if(which==1)x1 else x2).text.toString().toFloatOrNull() ?: 500f
        val y=(if(which==1)y1 else y2).text.toString().toFloatOrNull() ?: 1200f
        val n=count.text.toString().toIntOrNull()?.coerceIn(1,20) ?: 1
        val d=delay.text.toString().toLongOrNull()?.coerceIn(20,5000) ?: 100
        s.tapPattern(x,y,n,d)
    }
}
