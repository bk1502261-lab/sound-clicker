package com.example.soundtap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService: AccessibilityService() {
    companion object { @Volatile var instance: TapAccessibilityService?=null }
    private val handler=Handler(Looper.getMainLooper())
    override fun onServiceConnected(){super.onServiceConnected();instance=this}
    override fun onAccessibilityEvent(event:AccessibilityEvent?){}
    override fun onInterrupt(){}
    override fun onDestroy(){instance=null;handler.removeCallbacksAndMessages(null);super.onDestroy()}
    fun tapPattern(x:Float,y:Float,count:Int,intervalMs:Long){
        val n=count.coerceIn(1,20); val d=intervalMs.coerceIn(20,5000)
        repeat(n){i->handler.postDelayed({tap(x,y)},i*d)}
    }
    private fun tap(x:Float,y:Float){
        val path=Path().apply{moveTo(x,y)}
        val stroke=GestureDescription.StrokeDescription(path,0,40)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(),null,null)
    }
}
