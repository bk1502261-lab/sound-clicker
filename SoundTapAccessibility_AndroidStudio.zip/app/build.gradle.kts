plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="com.example.soundtap"
    compileSdk=35
    defaultConfig {
        applicationId="com.example.soundtap"
        minSdk=26
        targetSdk=35
        versionCode=1
        versionName="1.0"
    }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}
