# Sound Tap Helper
Accessibility-based Android tap helper for testing coordinate taps from an external detector such as a Termux FFT detector.

Build in Android Studio, install APK, enable the Accessibility service, set Button 1/2 coordinates, then test.

This project does not place trades or automate financial transactions. Verify coordinates in a harmless test screen before connecting any external trigger.
